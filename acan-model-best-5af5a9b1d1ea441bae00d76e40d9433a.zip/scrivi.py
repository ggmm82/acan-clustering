"""Scrive con il modello a concetti di questa cartella: python scrivi.py "domanda" (conversazione) o --testo "inizio"."""
import argparse
from pathlib import Path

from safetensors.numpy import load_file
from transformers import AutoTokenizer

from acan.lm.concept_lm import from_checkpoint_arrays

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('domanda', nargs='?', default='Ciao! Chi sei?')
parser.add_argument('--testo', help='continua questo testo invece di rispondere a una domanda')
parser.add_argument('--token', type=int, default=128)
parser.add_argument('--temperatura', type=float, default=0.7)
parser.add_argument('--seme', type=int, default=0)
args = parser.parse_args()
arrays = load_file(str(here/'concepts.safetensors'))
model = from_checkpoint_arrays(arrays)
tokenizer = AutoTokenizer.from_pretrained(str(here/'tokenizer'), local_files_only=True)
prompt = args.testo if args.testo else f"<|im_start|>user\n{args.domanda.strip()}<|im_end|>\n<|im_start|>assistant\n"
stop = {tokenizer.eos_token_id, tokenizer.convert_tokens_to_ids('<|im_end|>')} - {None, tokenizer.unk_token_id}
produced = model.generate(tokenizer(prompt)['input_ids'], args.token, stop=stop, temperature=args.temperatura, seed=args.seme)
print(tokenizer.decode(produced, skip_special_tokens=True))
