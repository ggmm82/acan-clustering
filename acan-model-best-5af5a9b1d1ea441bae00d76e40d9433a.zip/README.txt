Modello linguistico a concetti ACAN.

concepts.safetensors   i parametri della rete a concetti (le voci net.*): i concetti dei token e di ogni strato,
                       imparati col gradiente, e la memoria del documento. Tutto si legge con numpy, senza PyTorch.
                       (safetensors: un formato standard e sicuro per tabelle di numeri)
tokenizer/             il tokenizer che trasforma il testo in token e viceversa
scrivi.py              uno script pronto: carica il modello e scrive
config.json            le impostazioni dell'apprendimento
training-summary.json  passi, token letti, errore su testo mai visto, concetti per strato
export-manifest.json   le impronte SHA-256 di ogni file

Non contiene il testo di addestramento.

Per usarlo serve Python con il pacchetto acan (lo stesso del server), transformers e safetensors:
    pip install safetensors transformers
    python scrivi.py "Ciao! Chi sei?"
    python scrivi.py --testo "C'era una volta"

In Python:
    from acan.lm.concept_lm import from_checkpoint_arrays
    from safetensors.numpy import load_file
    from transformers import AutoTokenizer
    model = from_checkpoint_arrays(load_file("concepts.safetensors"))
    tokenizer = AutoTokenizer.from_pretrained("tokenizer")
    ids = tokenizer("C'era una volta")["input_ids"]
    print(tokenizer.decode(model.generate(ids, 64, temperature=0.7, seed=0)))
    p = model.distribution(ids)      # la probabilità di ogni token del vocabolario
